<template>
  <div class="container">
    <div class="text-center">
      <div class="search-bar">
        <input
          class="view"
          type="text"
          value="search"
          placeholder="그룹명 검색"
          @input="updateSearch($event.target.value)"
        />
        <b-button
          class="btn btn-sm"
          @click="searchGroup"
          style="background-color: #f3df8c"
          >검색</b-button
        >
      </div>
      <router-link
        :to="{ name: 'Regist' }"
        class="new-group-link"
        style="color: black"
      >
        <img class="icon" src="@/assets/plus.png" />새로운 그룹 만들기
      </router-link>
    </div>
    <br />
    <hr />
    <div>
      <h2>검색 결과</h2>
      <b-card-group deck>
        <b-row>
          <b-col
            :cols="4"
            v-for="(group, index) in paginatedGroups"
            :key="index"
          >
            <b-card
              :title="group.name"
              :img-src="getRandomImage()"
              img-alt="img"
              img-top
              tag="article"
              style="max-width: 22rem"
              class="mb-2"
            >
              <hr />
              <b-card-text>그룹 설명: {{ group.detail }}</b-card-text>
              <b-card-text>그룹장: {{ group.master }}</b-card-text>
              <b-button
                variant="warning"
                @click="joinGroup(group)"
                style="background-color: #f3df8c"
                >가입하기</b-button
              >
            </b-card>
          </b-col>
        </b-row>
      </b-card-group>
      <div v-if="!searchGroupCnt">검색 결과가 없습니다.</div>

      <!-- Pagination -->
      <ul class="pagination">
        <li
          class="page-item"
          :class="{ active: currentPage === page }"
          v-for="page in totalPages"
          :key="page"
        >
          <a class="page-link" href="#" @click="setCurrentPage(page)">{{
            page
          }}</a>
        </li>
      </ul>
    </div>
    <br />
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";

export default {
  name: "GroupSearch",
  data() {
    return {
      search: "",
      currentPage: 1,
      perPage: 6,
    };
  },
  methods: {
    updateSearch(value) {
      this.search = value;
    },
    searchGroup() {
      this.$store.dispatch("searchGroupName", this.search);
      this.setCurrentPage(1);
    },
    joinGroup(group) {
      console.log(group);
      alert("그룹에 가입하셨습니다!");
    },
    getRandomImage() {
      const width = 600; // 이미지 너비
      const height = 300; // 이미지 높이
      const randomImageId = Math.floor(Math.random() * 1000); // 0부터 999까지의 랜덤 이미지 ID
      return `https://picsum.photos/${width}/${height}?random=${randomImageId}`;
    },
    setCurrentPage(page) {
      this.currentPage = page;
    },
  },
  computed: {
    ...mapState(["searchGroups"]),
    ...mapGetters(["searchGroupCnt"]),
    totalPages() {
      return Math.ceil(this.searchGroups.length / this.perPage);
    },
    paginatedGroups() {
      const startIndex = (this.currentPage - 1) * this.perPage;
      const endIndex = startIndex + this.perPage;
      return this.searchGroups.slice(startIndex, endIndex);
    },
  },
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}

.search-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 10px;
}

.view {
  width: 300px;
}

.new-group-link {
  float: right;
}
.view {
  width: 300px;
  margin: 15px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 15px;
}

.pagination .page-item.disabled .page-link {
  opacity: 0.5;
  cursor: not-allowed;
}

.pagination .page-item.active .page-link {
  background-color: #f3df8c;
  border-color: #f3df8c;
}
/* f9f984, dbd174, f3df8c, dbbc74 */

.pagination .page-link {
  color: #f3df8c;
  background-color: #fff;
  border: 1px solid #dee2e6;
  padding: 6px 12px;
  margin: 0 3px;
  border-radius: 3px;
  transition: background-color 0.3s, border-color 0.3s, color 0.3s;
  cursor: pointer;
}

.pagination .page-link:hover {
  background-color: #f3df8c;
  border-color: #f3df8c;
  color: #fff;
}

.pagination .page-item:first-child .page-link {
  border-top-left-radius: 3px;
  border-bottom-left-radius: 3px;
}

.pagination .page-item:last-child .page-link {
  border-top-right-radius: 3px;
  border-bottom-right-radius: 3px;
}

.pagination .page-link:focus,
.pagination .page-link.focus {
  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}
.icon {
  width: 25px;
  margin: 5px;
}
</style>
