<template>
  <div class="container">
    <h2>새로운 그룹 만들기</h2>
    <fieldset class="text-center">
      <div class="form-group">
        <label for="name">그룹명</label>
        <input type="text" id="name" v-model="name" class="view" />
      </div>
      <div class="form-group">
        <label for="password">비밀번호</label>
        <input type="password" id="password" v-model="password" class="view" />
      </div>
      <div class="form-group">
        <label for="detail">상세 설명</label>
        <input type="text" id="detail" v-model="detail" class="view" />
      </div>
      <div class="form-group">
        <label for="notice">공지</label>
        <input type="text" id="notice" v-model="notice" class="view" />
      </div>
      <div class="form-group">
        <label for="master">그룹장</label>
        <input type="text" id="master" v-model="master" class="view" readonly />
      </div>
      <div class="bcontainer">
        <button class="btn" @click="regist">그룹 등록</button>
      </div>
    </fieldset>
  </div>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "GroupRegist",
  // ...
  data() {
    return {
      name: "",
      password: "",
      detail: "",
      notice: "",
      master: "",
    };
  },
  computed: {
    ...mapState(["loginUser"]),
    getUser() {
      if (this.loginUser) {
        return true;
      } else {
        return false;
      }
    },
  },
  methods: {
    regist() {
      if (!this.loginUser) {
        alert("그룹 생성을 위해 로그인이 필요합니다.");
        this.$router.push("/login");
        return;
      }

      if (
        this.name === "" ||
        this.password === "" ||
        this.detail === "" ||
        this.notice === ""
      ) {
        alert("모든 내용을 입력해주세요");
        return;
      }

      let group = {
        userid: this.loginUser.id,
        id: 0,
        name: this.name,
        password: this.password,
        detail: this.detail,
        notice: this.notice,
        master: this.master,
      };

      this.$store.dispatch("createGroup", group);
    },
  },

  created() {
    if (this.loginUser) {
      this.master = this.loginUser.nickname;
    }
  },
};
</script>

<style scoped>
h2 {
  margin-top: 20px;
  margin-bottom: 20px;
  margin-left: 10px;
}

label {
  margin-bottom: 0px;
}

.container {
  /* background-color: #6da258; */
  border-radius: 30px;
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url("@/assets/공사중.png");
  background-size: cover;
  background-position: center;
}

.form-group {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 10px;
}

.form-group label {
  margin-right: 10px;
  width: 80px; /* 라벨의 너비 설정 */
}

.input-group {
  display: flex;
  flex-grow: 1;
}

.input-group .btn {
  margin-left: 10px;
  white-space: nowrap;
}

.btn-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}
.btn {
  white-space: nowrap;
}

.view {
  height: 33px;
  flex-grow: 1;
  display: flex;
  align-items: center;
  padding-left: 15px;
}
.bcontainer {
  background-color: #6da258;
  border-radius: 25px;
  margin-bottom: 20px;
  margin-top: 20px;
  width: 30%;
  margin-left: 270px;
}
.view[readonly] {
  color: gray;
}
</style>
