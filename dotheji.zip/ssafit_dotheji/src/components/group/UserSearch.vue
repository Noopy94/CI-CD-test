<template>
  <div class="container">
    <div class="text-center">
      <img src="@/assets/following.png" />
      <input
        class="view"
        type="text"
        v-model="search"
        placeholder="유저 닉네임을 검색하세요"
        @keyup.enter="searchUser"
      />
      <button class="btn" @click="searchUser">검색</button>
    </div>
    <br />
    <div>
      <h2>검색 결과</h2>
      <hr />
      <div v-if="searchUserCnt">
        <table class="user-list">
          <colgroup>
            <col style="width: 15%" />
            <col style="width: 49%" />
            <col style="width: 25%" />
            <col style="width: 40%" />
          </colgroup>
          <thead>
            <tr>
              <th class="text-center">번호</th>
              <th class="text-center">닉네임</th>
              <th class="text-center">아이디</th>
              <th class="text-center">초대하기</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(user, index) in searchUsers" :key="index">
              <td class="text-center">{{ index + 1 }}</td>
              <td class="text-center">{{ user.nickname }}</td>
              <td class="text-center">{{ user.user_id }}</td>
              <td class="text-center">
                <b-button variant="success" size="sm" @click="invite(user)"
                  >초대하기</b-button
                >
              </td>
            </tr>
          </tbody>
        </table>
        <hr />
      </div>
      <div v-else>검색 결과가 없습니다.</div>

      <div class="d-flex justify-content-end align-items-center mt-3">
        <router-link :to="`/${groupid}`" class="mr-3" style="color: black">
          <img class="icon" src="@/assets/repeat.png" />
          내 그룹으로 돌아가기
        </router-link>
      </div>
    </div>
    <br />
  </div>
</template>
<script>
import { mapState, mapGetters } from "vuex";
export default {
  name: "UserSearch",
  data() {
    return {
      groupid: 0,
      search: "",
    };
  },
  methods: {
    searchUser() {
      this.$store.dispatch("searchName", this.search);
    },
    invite(user) {
      // if (!this.loginUser) {
      //   alert("그룹 생성을 위해 로그인이 필요합니다.");
      //   this.$router.push("/login");
      //   return;
      // }

      let i = {
        groupid: this.groupid,
        id: user.id,
        password: user.password,
        nickname: user.nickname,
        user_id: user.user_id,
        height: user.height,
        weight: user.weight,
        exp: user.exp,
      };

      this.$store.dispatch("inviteUser", i);
    },
  },
  computed: {
    ...mapState(["searchUsers"]),
    ...mapGetters(["searchUserCnt"]),
  },
  created() {
    const pathName = new URL(document.location).pathname.split("/");
    const groupid = pathName[pathName.length - 2];
    this.groupid = parseInt(groupid, 10);
  },
};
</script>
<style scoped>
h2 {
  margin-bottom: 15px;
}
img {
  width: 25px;
  margin-right: 15px;
}
input {
  margin-top: 35px;
  height: 40px;
  padding-left: 20px;
}
.user-list {
  margin-left: 220px;
}
/* Add spacing to the table rows */
tr {
  margin-bottom: 30px;
}
td {
  height: 60px; /* Adjust the height as needed */
}
</style>
