<template>
  <div class="container">
    <h2>내가 속한 그룹</h2>
    <b-carousel
      id="group-carousel"
      :interval="4000"
      controls
      indicators
      background="#ababab"
      img-width="800"
      img-height="400"
      style="text-shadow: 1px 1px 2px #333;"
      @sliding-start="onSlideStart"
      @sliding-end="onSlideEnd"
    >
      <b-carousel-slide v-for="(group, index) in groups" :key="index">
        <div class="slide-content">
          <h1>{{ group.name }}</h1>
          <p>그룹장명: {{ group.master }}</p>
          <p>그룹설명: {{ group.detail }}</p>
          <router-link class="group-link" :to="`/${group.id}`" style="color: black; font-size: 20px">
            그룹 상세보기
          </router-link>
        </div>
        <template #img>
          <img :src="getRandomGif()" alt="Group Image" />
        </template>
      </b-carousel-slide>
    </b-carousel>
    <div class="d-flex justify-content-end align-items-center mt-3">
      <router-link :to="{ name: 'GroupSearch' }" class="mr-3" style="color: black;">
        <img class="icon" src="@/assets/plus.png" />
        그룹 추가하기
      </router-link>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "GroupList",
  computed: {
    ...mapState(["loginUser"]),
    ...mapState(["groups"]),
    id() {
      return this.loginUser.id;
    },
  },
  beforeMount() {
    this.$store.dispatch("setGroups", this.id);
  },
  methods: {
    getRandomGif() {
      const randomIndex = Math.floor(Math.random() * 10) + 1;
      return require(`@/assets/${randomIndex}.gif`);
    },
  },
};
</script>

<style scoped>
.icon {
  width: 50px;
}

.slide-content {
  text-align: right;
  padding: 1rem;
}

p {
  font-size: 20px;
}

</style>