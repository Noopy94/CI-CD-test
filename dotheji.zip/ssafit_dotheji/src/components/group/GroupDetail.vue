<template>
  <div class="container">
    <div class="text-center group-name">
      <h2>그룹명: {{ group.name }}</h2>
      <hr />
      <div class="announcement">
        <img
          class="announcement-icon"
          src="@/assets/notice.png"
          alt="Announcement"
        />
        <h3>공지사항: {{ group.notice }}</h3>
      </div>
    </div>
    <div class="edit-button-container">
      <h4>그룹 수정하기</h4>
      <img
        class="edit-button"
        src="@/assets/pen.png"
        alt="Edit"
        @click="showUpdateGroupModal"
      />
    </div>
    <div class="participants">
      <h4>{{ UsersCnt }}명 운동중</h4>
      <img
        class="participants-icon"
        src="@/assets/운동중.gif"
        alt="Participants"
      />
    </div>
    <h3 class="text-center group-name2">그룹원 현황</h3>
    <fieldset>
      <table class="user-list">
        <colgroup>
          <col style="width: 15%" />
          <col style="width: 49%" />
          <col style="width: 25%" />
          <col style="width: 40%" />
        </colgroup>
        <thead>
          <tr>
            <th class="text-center">번호</th>
            <th class="text-center">닉네임</th>
            <th class="text-center">운동시간</th>
            <th class="text-center">현재 상태</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(user, index) in users" :key="index">
            <td class="text-center">{{ index + 1 }}</td>
            <td class="text-center">{{ user.nickname }}</td>
            <td class="text-center">09:00</td>
            <td class="text-center">
              <img
                class="status-icon"
                src="@/assets/오구 운동중.gif"
                alt="Status"
              />
            </td>
          </tr>
        </tbody>
      </table>
    </fieldset>
    <hr />

    <div class="d-flex justify-content-end align-items-center mt-3">
      <router-link
        :to="`${group.id}/usersearch`"
        class="mr-3"
        style="color: black"
      >
        그룹원 초대하기
        <img class="icon" src="@/assets/location.png" />
      </router-link>
    </div>

    <b-modal
      v-model="showModal"
      title="그룹 수정하기"
      hide-footer
      @ok="updateGroup"
    >
      <p>이 기능은 아직 준비중입니다!</p>
    </b-modal>
  </div>
</template>

<script>
import { mapGetters, mapState } from "vuex";

export default {
  name: "GroupDetail",
  methods: {
    showUpdateGroupModal() {
      this.showModal = true;
    },
    updateGroup() {
      // Add your logic here to update the group
      this.$store.dispatch("updateGroup", this.group);

      // Close the modal
      this.showModal = false;
    },
  },
  computed: {
    ...mapState(["group"]),
    ...mapState(["users"]),
    ...mapGetters(["UsersCnt"]),
  },
  created() {
    const pathName = new URL(document.location).pathname.split("/");
    const id = parseInt(pathName[pathName.length - 1], 10);
    this.$store.dispatch("setGroup", id);
    this.$store.dispatch("setUsers", id);
  },
  data() {
    return {
      showModal: false,
    };
  },
};
</script>

<style scoped>
.user-list {
  margin-left: 180px;
}
.text-center {
  text-align: center;
}
h2 {
  margin-top: 10px;
}
.group-name {
  border: 2px solid #5e8755;
  border-radius: 15px;
  padding: 10px;
  margin-bottom: 15px;
}
.group-name2 {
  background-color: #5e8755;
  border-radius: 15px;
  padding: 10px;
  margin-bottom: 15px;
}
.text-center {
  text-align: center;
  margin: 25px;
}

.edit-button-container {
  display: flex;
  align-items: center;
  justify-content: flex-end;
}

.edit-button {
  width: 50px;
  margin-left: 10px;
}

.edit-button:hover {
  cursor: pointer;
}

.announcement {
  display: flex;
  align-items: center;
  justify-content: center;
}

.announcement-icon {
  width: 40px;
  height: 40px;
  margin-right: 10px;
  margin-bottom: 10px;
}

.participants {
  display: flex;
  align-items: center;
  justify-content: center;
}

.participants-icon {
  width: 75px;
  height: 75px;
  margin-left: 10px;
  margin-bottom: 10px;
}

.status-icon {
  width: 60px;
}

.edit-button {
  width: 45px;
  margin-right: 30px;
}
.group-link {
  align-items: center;
  margin-left: 700px;
  margin-top: 20px;
}
img {
  width: 25px;
  margin-right: 15px;
}
</style>
