<template>
  <li @click="clickVideo">
    <img :src="video.snippet.thumbnails.default.url" />
    {{ video.snippet.title }} || 리뷰 수 {{ comments.length }}
    <hr />
  </li>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "VideoItem",
  props: {
    video: {
      type: Object,
      required: true,
    },
  },
  computed: {
    ...mapState(["comments"]),
  },
  methods: {
    clickVideo() {
      this.$store.dispatch("clickVideo", this.video);
      this.$store.dispatch("getComments", this.video);
    },
  },
};
</script>

<style scoped>
li {
  margin-top: 18px;
}
img {
  margin-right: 30px;
}
</style>
