<template>
  <div>
    <h2 v-if="videos">검색 결과</h2>
    <ul class="youtube-list">
      <video-item
        v-for="video in videos"
        :key="video.id.videoId"
        :video="video"
        :comments="comments"
      ></video-item>
    </ul>
  </div>
</template>

<script>
import { mapState } from "vuex";
import VideoItem from "@/components/video/VideoItem.vue";

export default {
  components: { VideoItem },
  name: "VideoResult",
  computed: {
    ...mapState(["videos"]),
    ...mapState(["comments"]),
  },
};
</script>

<style scoped>
h2 {
  margin-left: 30px;
}
.youtube-list {
  text-align: left;
  margin-left: 30px;
}
</style>
