<template>
  <div v-if="video">
    <h2>영상 보기</h2>
    <iframe
      width="560"
      height="315"
      :src="videoURL()"
      title="YouTube video player"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      allowfullscreen
    ></iframe>
  </div>
</template>

<script>
export default {
  name: "VideoD",
  data() {
    return {
      videoURL: "",
    };
  },
  created() {
    const videoURL = () => {
      console.log("와라");
      const pathName = new URL(document.location).pathname.split("/");
      const id = pathName[pathName.length - 1];
      return `https://www.youtube.com/embed/${id}`;
    };
    this.videoURL = videoURL;
  },
};
</script>

<style></style>
