<template>
  <div class="container">
    <div class="text-center">
      <img src="@/assets/search.png" />
      <input
        class="view"
        type="text"
        v-model="keyword"
        placeholder="관심있는 운동을 검색하세요"
        @keyup.enter="search"
      />
      <button class="btn" @click="search">검색</button>
    </div>
    <br />
  </div>
</template>

<script>
export default {
  name: "VideoSearch",
  data() {
    return {
      keyword: "",
    };
  },
  methods: {
    search() {
      this.$store.dispatch("searchYoutube", this.keyword);
    },
  },
};
</script>
<style scoped>
img {
  width: 25px;
  margin-right: 15px;
}
input {
  margin-top: 30px;
  height: 40px;
  padding-left: 20px;
}
</style>
