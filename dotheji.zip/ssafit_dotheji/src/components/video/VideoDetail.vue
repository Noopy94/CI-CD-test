<template>
  <div v-if="video" class="video-container">
    <h2>영상 보기</h2>
    <div class="iframe">
      <iframe
        width="650"
        height="365"
        :src="videoURL"
        title="YouTube video player"
        frameborder="0"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen
      ></iframe>
    </div>
    <hr />
    <comment-regist></comment-regist>
    <comment-list></comment-list>
  </div>
</template>

<script>
import { mapState } from "vuex";
import CommentList from "../comment/CommentList.vue";
import CommentRegist from "../comment/CommentRegist.vue";
export default {
  components: { CommentRegist, CommentList },
  name: "VideoDetail",
  computed: {
    ...mapState(["video"]),
    videoURL() {
      const videoId = this.video.id.videoId;
      return `https://www.youtube.com/embed/${videoId}`;
    },
  },
};
</script>

<style>
.video-container {
  text-align: center;
}

.iframe {
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
