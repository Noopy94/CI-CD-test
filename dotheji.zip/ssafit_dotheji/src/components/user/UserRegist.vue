<template>
  <div class="container">
    <h2>회원 가입</h2>
    <fieldset class="text-center">
      <div class="form-group">
        <label for="user_id">아이디</label>
        <div class="input-group">
          <input type="text" id="user_id" v-model="user_id" class="view" />
          <button class="btn" @click="checkId">중복 확인</button>
        </div>
      </div>
      <div class="form-group">
        <label for="password">비밀번호</label>
        <div class="input-group">
          <input
            type="password"
            id="password"
            v-model="password"
            class="view"
          />
        </div>
      </div>
      <div class="form-group">
        <label for="password2" class="label-color">재입력</label>
        <div class="input-group">
          <input type="password" id="password2" class="view" />
          <span id="check"></span>
          <button class="btn" @click="checking">일치 확인</button>
        </div>
      </div>
      <div class="form-group">
        <label for="nickname">닉네임</label>
        <div class="input-group">
          <input type="text" id="nickname" v-model="nickname" class="view" />
          <button class="btn" @click="checkNickname">중복 확인</button>
        </div>
      </div>
      <div class="form-group">
        <label for="height">키</label>
        <div class="input-group">
          <input type="number" id="height" v-model="height" class="view" />
        </div>
      </div>
      <div class="form-group">
        <label for="weight">몸무게</label>
        <div class="input-group">
          <input type="number" id="weight" v-model="weight" class="view" />
        </div>
      </div>
      <div class="btn-container">
        <button class="btn" @click="regist">등록</button>
      </div>
    </fieldset>
  </div>
</template>
<script>
// import { mapState } from "vuex";
export default {
  name: "UserRegist",
  data() {
    return {
      user_id: "",
      password: "",
      nickname: "",
      height: "",
      weight: "",
      idcheck: false,
      nicknamecheck: false,
      pwcheck: false,
    };
  },
  methods: {
    regist() {
      if (
        this.user_id === "" ||
        this.password === "" ||
        this.nickname === "" ||
        this.height === "" ||
        this.weight === ""
      ) {
        alert("모든 내용을 입력해주세요");
        return;
      }

      if (this.idcheck === false) {
        alert("id 중복확인을 해주세요");
        return;
      }
      if (this.nicknamecheck === false) {
        alert("nickname 중복확인을 해주세요");
        return;
      }
      if (this.pwcheck === false) {
        alert("password 중복확인을 해주세요");
        return;
      }

      let user = {
        id: 0,
        user_id: this.user_id,
        password: this.password,
        nickname: this.nickname,
        height: this.height,
        weight: this.weight,
        exp: 0,
      };

      this.$store.dispatch("createUser", user);
    },

    checkId() {
      if (this.user_id === "") {
        alert("id를 입력해주세요");
        return;
      }
      let user_id = this.user_id;

      this.$store.dispatch("checkId", user_id);

      this.idcheck = this.$store.state.idcheck;
    },
    checkNickname() {
      if (this.nickname === "") {
        alert("nickname을 입력해주세요");
        return;
      }
      let nickname = this.nickname;

      this.$store.dispatch("checkNickname", nickname);

      this.nicknamecheck = this.$store.state.nicknamecheck;
    },
    checking() {
      var pw = document.getElementById("password").value;
      var SC = ["!", "@", "#", "$", "%"];
      var check_SC = 0;

      if (pw.length < 6 || pw.length > 16) {
        window.alert("비밀번호는 6글자 이상, 16글자 이하만 이용 가능합니다.");
        document.getElementById("password").value = "";
      }
      for (var i = 0; i < SC.length; i++) {
        if (pw.indexOf(SC[i]) != -1) {
          check_SC = 1;
        }
      }
      if (check_SC == 0) {
        window.alert("!,@,#,$,% 의 특수문자가 들어가 있지 않습니다.");
        document.getElementById("password").value = "";
      }
      if (
        document.getElementById("password").value != "" &&
        document.getElementById("password2").value != ""
      ) {
        if (
          document.getElementById("password").value ==
          document.getElementById("password2").value
        ) {
          document.getElementById("check").innerHTML = "비밀번호가 일치합니다.";
          document.getElementById("check").style.color = "blue";
          this.pwcheck = true;
        } else {
          document.getElementById("check").innerHTML =
            "비밀번호가 일치하지 않습니다.";
          document.getElementById("check").style.color = "red";
        }
      }
    },
  },
  // computed: {
  //   ...mapState(["idcheck", "pwcheck"]),
  // },
};
</script>

<style scoped>
#check {
  margin-left: 10px;
  padding-top: 5px;
  color: blue;
}
.label-color {
  color: rgb(39, 39, 206); /* 원하는 색상으로 변경하세요 */
}
h2 {
  margin-top: 20px;
  margin-bottom: 20px;
}

label {
  margin-bottom: 0px;
}

.container {
  background-color: #6da258;
  border-radius: 30px;
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url("@/assets/공사중.png");
  background-size: cover;
  background-position: center;
}

.form-group {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 10px;
}

.form-group label {
  margin-right: 10px;
  width: 80px; /* 라벨의 너비 설정 */
}

.input-group {
  display: flex;
  flex-grow: 1;
  margin: 0px;
}

.input-group .btn {
  margin-left: 10px;
  white-space: nowrap;
}

.btn-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
  margin-bottom: 10px;
}
.btn {
  white-space: nowrap;
  background-color: #6da258;
  border-radius: 25px;
}

.view {
  height: 35px;
  flex-grow: 1;
  display: flex;
  align-items: center;
}
</style>
