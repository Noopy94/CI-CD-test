<template>
  <div>
    <div class="container">
      <h2>회원 정보 수정</h2>
      <fieldset class="text-center">
        <div class="form-group">
          <label for="user_id">아이디</label>
          <div class="input-group">
            <input
              type="text"
              id="user_id"
              v-model="user_id"
              class="view"
              readonly
            />
          </div>
        </div>
        <div class="form-group">
          <label for="password">비밀번호</label>
          <div class="input-group">
            <input
              type="password"
              id="password"
              v-model="password"
              class="view"
              readonly
            />
          </div>
        </div>
        <div class="form-group">
          <label for="nickname">닉네임</label>
          <div class="input-group">
            <input type="text" id="nickname" v-model="nickname" class="view" />
            <button
              class="btn"
              @click="checkNickname"
              @keyup.enter="checkNickname"
            >
              중복확인
            </button>
          </div>
        </div>
        <div class="form-group">
          <label for="height">키</label>
          <div class="input-group">
            <input
              type="number"
              id="height"
              v-model="height"
              class="view"
              @keyup.enter="modify"
            />
          </div>
        </div>
        <div class="form-group">
          <label for="weight">몸무게</label>
          <div class="input-group">
            <input
              type="number"
              id="weight"
              v-model="weight"
              class="view"
              @keyup.enter="modify"
            />
          </div>
        </div>
        <div class="btn-container">
          <button class="btn" @click="modify">정보 수정</button>
        </div>
      </fieldset>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "UserModify",
  data() {
    return {
      nicknamecheck: false,
      nickname: "",
    };
  },
  computed: {
    ...mapState(["loginUser"]),
  },
  created() {
    if (this.loginUser) {
      this.id = this.loginUser.id;
      this.user_id = this.loginUser.user_id;
      this.password = this.loginUser.password;
      this.nickname = this.loginUser.nickname;
      this.height = this.loginUser.height;
      this.weight = this.loginUser.weight;
      this.exp = this.loginUser.exp;
    }
  },
  methods: {
    modify() {
      if (this.nickname === "" || this.height === "" || this.weight === "") {
        alert("모든 내용을 입력해주세요");
        return;
      }

      if (this.nicknamecheck === false) {
        alert("nickname 중복확인을 해주세요");
        return;
      }

      let user = {
        id: this.loginUser.id,
        user_id: this.user_id,
        password: this.password,
        nickname: this.nickname,
        height: this.height,
        weight: this.weight,
        exp: this.loginUser.exp,
      };

      this.$store.dispatch("modifyUser", user);
      this.$store.commit("LOGOUT");
      this.$router.push("/login");
    },

    checkNickname() {
      if (this.nickname === this.loginUser.nickname) {
        this.nicknamecheck = true;
        alert("중복확인 되었습니다.");
        return;
      }
      if (this.nickname === "") {
        alert("nickname을 입력해주세요");
        return;
      }
      let nickname = this.nickname;

      this.$store.dispatch("checkNickname", nickname);

      this.nicknamecheck = this.$store.state.nicknamecheck;
    },
  },
};
</script>

<style scoped>
h2 {
  margin-top: 20px;
  margin-bottom: 20px;
}

.container {
  background-color: #6da258;
  border-radius: 30px;
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url("@/assets/공사중.png");
  background-size: cover;
  background-position: center;
}

.form-group {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 10px;
}

.form-group label {
  margin-right: 10px;
  width: 80px; /* 라벨의 너비 설정 */
}

.input-group {
  display: flex;
  flex-grow: 1;
  margin: 0px;
}

.input-group .btn {
  margin-left: 10px;
  white-space: nowrap;
}

.btn-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 10px;
  margin-bottom: 10px;
}

.btn {
  white-space: nowrap;
  background-color: #6da258;
  border-radius: 25px;
}

.view {
  height: 35px;
  flex-grow: 1;
  display: flex;
  align-items: center;
  padding-left: 15px;
}
.view[readonly] {
  color: gray;
}
</style>
