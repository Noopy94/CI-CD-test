<template>
  <div class="container">
    <h2>마이페이지</h2>
    <fieldset class="text-center">
      <img
        v-if="loginUser && loginUser.exp === 0"
        src="@/assets/오구.png"
        alt="공사중 이미지"
        class="image-placeholder"
      />

      <div class="form-group">
        <label for="user_id">아이디</label>
        <input
          type="text"
          id="user_id"
          v-model="user_id"
          class="view"
          readonly
        />
      </div>
      <div class="form-group">
        <label for="nickname">닉네임</label>
        <input
          type="text"
          id="nickname"
          v-model="nickname"
          class="view"
          readonly
        />
      </div>
      <div class="form-group">
        <label for="height">키</label>
        <input
          type="number"
          id="height"
          v-model="height"
          class="view"
          readonly
        />
      </div>
      <div class="form-group">
        <label for="weight">몸무게</label>
        <input
          type="number"
          id="weight"
          v-model="weight"
          class="view"
          readonly
        />
      </div>
      <div class="form-group">
        <label for="exp">경험치</label>
        <input type="text" id="exp" v-model="exp" class="view" readonly />
      </div>
      <router-link :to="{ name: 'Modify' }" class="modify-link"
        >정보 수정하기</router-link
      >
      <hr />
      <template>
        <div>
          <b-form-group label="나의 운동 일지" v-slot="{ ariaDescribedby }">
            <b-form-radio-group
              v-model="state"
              :aria-describedby="ariaDescribedby"
              aria-controls="ex-disabled-readonly"
            >
            </b-form-radio-group>
          </b-form-group>

          <b-calendar
            block
            locale="kr-US"
            id="ex-disabled-readonly"
            :disabled="disabled"
            :readonly="readonly"
          ></b-calendar>
        </div>
      </template>
    </fieldset>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  data() {
    return {
      state: "disabled",
    };
  },
  name: "UserMypage",
  computed: {
    ...mapState(["loginUser"]),
  },
  mounted() {
    const calendarHelpElement = document.querySelector("#calendar-help .small");
    if (calendarHelpElement) {
      calendarHelpElement.textContent = this.calendarHelpText;
    }
  },
  created() {
    if (this.loginUser) {
      this.user_id = this.loginUser.user_id;
      this.nickname = this.loginUser.nickname;
      this.height = this.loginUser.height;
      this.weight = this.loginUser.weight;
      this.exp = this.loginUser.exp;
    }
  },
  methods: {
    usermodify() {
      if (!this.loginUser) {
        alert("정보 수정 페이지로 이동하기 위해 로그인을 해주세요");
        this.$router.push("/login");
        return;
      }
    },
  },
};
</script>

<style scoped>
img {
  width: 200px;
  height: 150px;
  overflow: hidden;
  position: absolute;
  top: 28%;
  left: 15%;
  border: 3px solid #000;
}
h2 {
  margin-top: 20px;
}

label {
  margin-bottom: 0px;
}
input {
  padding-left: 5px;
}

.container {
  background-color: #6da258;
  border-radius: 30px;
  margin-top: 20px;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url("@/assets/mypageimg.jpg");
  background-size: cover;
  background-position: center;
}

.form-group {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.form-group label {
  margin-right: 10px;
  width: 80px;
}

.view {
  height: 33px;
  flex-grow: 1;
  display: flex;
  align-items: center;
}

.modify-link {
  background-color: #6da258;
  border: 3px #6da258;
  margin-top: 20px;
  color: rgb(0, 0, 0); /* 원하는 폰트 색상으로 변경하세요 */
}
</style>
