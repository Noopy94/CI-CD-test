<template>
  <header>
    <nav class="header-nav">
      <div>
        <router-link :to="{ name: 'home' }"
          ><img class="logo" src="@/assets/home.png"
        /></router-link>
      </div>
      <div class="centered-container">
        <h2>DoTheJi</h2>
      </div>

      <div>
        <a href="/" v-if="getUser" @click="logout">
          <img class="logo" src="@/assets/door.png" />
        </a>
        <router-link v-if="getUser" :to="{ name: 'Mypage' }"
          ><img class="logo" src="@/assets/user.png"
        /></router-link>
        <router-link v-else :to="{ name: 'Login' }"
          ><img class="logo" src="@/assets/password.png"
        /></router-link>
        <!-- <router-link to="/video">비디오목록</router-link> -->
      </div>
    </nav>
  </header>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "HeaderNav",
  methods: {
    logout() {
      this.$store.commit("LOGOUT");
      alert("당신은 꿈꾸는 만큼 도달할 수 있습니다.");
    },
  },
  computed: {
    ...mapState(["loginUser"]),
    getUser() {
      if (this.loginUser) {
        return true;
      } else {
        return false;
      }
    },
  },
};
</script>
<style scoped>
header {
  height: 80px;
  background-color: #f3df8c;
  line-height: 80px;
  padding: 0px 20px;
}

header a {
  margin: 15px;
}

.header-nav {
  display: flex;
  justify-content: space-between;
}

.logo {
  display: inline-block;
  font-size: 2rem;
  font-weight: bold;
  /* color: white; */
  margin: 0;
  height: 70px;
}

.centered-container {
  display: flex;
  align-items: center;
}
</style>
