<template>
  <div>
    <ul>
      <comment-item
        v-for="comment in comments"
        :key="comment.Id"
        :comment="comment"
      ></comment-item>
    </ul>
  </div>
</template>

<script>
import { mapState } from "vuex";
import CommentItem from "@/components/comment/CommentItem.vue";

export default {
  components: { CommentItem },
  name: "CommentList",
  computed: {
    ...mapState(["comments"]),
  },
};
</script>

<style scoped>
.youtube-list {
  text-align: left;
}
div {
  margin-top: 25px;
}
</style>
