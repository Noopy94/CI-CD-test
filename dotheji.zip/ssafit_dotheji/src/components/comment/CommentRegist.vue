<template>
  <div class="container">
    <fieldset class="text-center">
      <label for="content">댓글 등록</label>
      <input
        type="text"
        id="content"
        v-model="content"
        class="view"
        placeholder="내용을 입력해주세요"
        @keyup.enter="regist"
      />
      <button class="btn" @click="regist">등록</button>
      <button class="btn" type="reset">취소</button>
    </fieldset>
  </div>
</template>
<script>
import { mapState } from "vuex";
export default {
  name: "CommentRegist",
  // ...
  computed: {
    ...mapState(["loginUser", "video"]),
  },
  methods: {
    regist() {
      // if (!this.loginUser) {
      //   alert("그룹 생성을 위해 로그인이 필요합니다.");
      //   this.$router.push("/login");
      //   return;
      // }

      if (this.content === "") {
        alert("내용을 입력해주세요");
        return;
      }

      if (!this.loginUser) {
        alert("로그인이 필요한 시스템입니다");
        return;
      }

      let comment = {
        user_id: this.loginUser.id,
        id: 0,
        content: this.content,
        youtube_id: this.video.id.videoId,
      };

      this.$store.dispatch("registComment", comment);
    },
  },
};
</script>
<style scoped>
label {
  margin-right: 30px;
}
input {
  margin-top: 30px;
  height: 35px;
  padding-left: 20px;
}
</style>
