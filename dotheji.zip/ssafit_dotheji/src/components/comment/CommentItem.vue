<template>
  <div>
    <li class="comment-item" @click="commentModify">
      <div class="image-container">
        <img src="@/assets/speech_3.png" class="comment-image" />
      </div>
      <div class="comment-content">
        {{ comment.content }}
      </div>
    </li>
    <hr />
  </div>
</template>

<script>
export default {
  name: "CommentItem",
  props: {
    comment: {
      type: Object,
      required: true,
    },
  },
  methods: {
    commentModify() {
      this.$store.dispatch("commentModify", this.comment);
    },
  },
};
</script>

<style scoped>
li {
  margin-top: 15px;
  display: flex;
  align-items: center;
}

.image-container {
  margin-right: 0px;
  margin-left: 100px;
}

.comment-image {
  width: 30px;
  height: 30px;
}

.comment-content {
  flex-grow: 1;
}
</style>
