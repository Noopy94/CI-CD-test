<template>
  <div class="container">
    <h2>로그인</h2>
    <fieldset class="text-center">
      <div class="input-container">
        <label for="user_id">아이디</label>
        <input type="text" id="user_id" v-model="user_id" class="view" />
      </div>
      <div class="input-container">
        <label for="password">비밀번호</label>
        <input
          type="password"
          id="password"
          v-model="password"
          class="view"
          @keyup.enter="login"
        />
      </div>
      <div class="b">
        <button class="btn" @click="login">로그인</button>
        <button class="btn" @click="$router.push({ name: 'Signup' })">
          회원가입
        </button>
      </div>
    </fieldset>
  </div>
</template>
<script>
export default {
  name: "LoginForm",
  data() {
    return {
      user_id: "",
      password: "",
    };
  },
  methods: {
    login() {
      let user = {
        user_id: this.user_id,
        password: this.password,
      };

      this.$store.dispatch("userLogin", user);
    },
  },
};
</script>
<style scoped>
label {
  margin-bottom: 0px;
}
h2 {
  padding: 10px;
}
.container {
  background-color: #6da258;
  border-radius: 30px;
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  background-image: url("@/assets/공사중.png");
  background-size: cover;
  background-position: center;
}

.input-container {
  justify-content: space-between;
  display: flex;
  align-items: center;
  margin-bottom: 10px;
}

.input-container label {
  width: auto;
  margin-right: 10px;
}

.view {
  width: 240px;
  display: flex;
  align-items: center;
}
.b {
  margin-bottom: 15px;
}
</style>
