<template>
  <div>
    <router-view></router-view>
    <!-- <video-search></video-search> -->
    <!-- <hr /> -->
    <video-detail></video-detail>
    <video-result></video-result>
  </div>
</template>

<script>
// import VideoSearch from "@/components/video/VideoSearch.vue";
import VideoResult from "@/components/video/VideoResult.vue";
import VideoDetail from "@/components/video/VideoDetail.vue";

export default {
  name: "VideoView",
  components: {
    // VideoSearch,
    VideoResult,
    VideoDetail,
  },
};
</script>

<style></style>
