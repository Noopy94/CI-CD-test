<template>
  <div class="container">
    <div class="text-center">
      <div class="time-container">
        <h3 class="today-time">오늘 운동 시간</h3>
        <div class="total-time">{{ formatTime(totalTime) }}</div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <div v-for="(item, index) in timers" :key="index" class="timer">
          <div class="timer-display">
            <img :src="getExerciseImage(index)" class="exercise-image" />
            <h3 class="timer-text">{{ exercises[index] }}</h3>
            <h1 class="timer-value">{{ formatTime(item.value) }}</h1>
            <div class="button-group">
              <b-button
                v-if="!item.running"
                variant="success"
                @click="startTimer(index)"
                class="timer-button"
              >
                <b-icon icon="play-fill"></b-icon>
              </b-button>
              <b-button
                v-if="item.running"
                variant="danger"
                @click="stopTimer(index)"
                class="timer-button"
              >
                <b-icon icon="stop-fill"></b-icon>
              </b-button>
            </div>
            <div>
              <b-button variant="warning" @click="openModal('addExercise')"
                >운동 수정</b-button
              >
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="d-flex flex-row justify-content-end">
      <b-button variant="warning" @click="goToGroupList"
        >내 그룹으로 가기</b-button
      >
    </div>

    <!-- 운동 추가하기 모달 -->
    <b-modal v-model="showModal" title="운동 추가하기" hide-footer>
      <div class="text-center">
        <h3>추가할 운동 입력</h3>
        <input
          class="view"
          type="text"
          v-model="exerciseTitle"
          placeholder="운동 제목"
        />
        <b-button
          variant="warning"
          @click="addExercise"
          class="btn btn-sm modal-button"
          >추가</b-button
        >
      </div>
    </b-modal>

    <!-- 음악 재생을 위한 오디오 요소 -->
    <audio ref="audioElement" src="@/assets/music.mp3" preload="auto"></audio>
  </div>
</template>

<script>
import { BButton, BIcon, BModal } from "bootstrap-vue";

export default {
  components: {
    BButton,
    BIcon,
    BModal,
  },
  data() {
    return {
      timers: [
        { value: 0, running: false },
        { value: 0, running: false },
        { value: 0, running: false },
      ],
      exercises: ["상체", "하체", "전신"],
      totalTime: 0,
      isRunning: false,
      showModal: false,
      exerciseTitle: "",
      activeTimerIndex: null,
    };
  },
  methods: {
    startTimer(index) {
      if (!this.timers[index].running) {
        if (this.activeTimerIndex !== null) {
          this.stopTimer(this.activeTimerIndex);
        }
        this.activeTimerIndex = index;

        this.timers[index].running = true;
        this.timers[index].intervalId = setInterval(() => {
          this.timers[index].value++;
          this.totalTime++;
        }, 1000);

        // 음악 재생
        this.$refs.audioElement.play();
      }
    },
    stopTimer(index) {
      clearInterval(this.timers[index].intervalId);
      this.timers[index].running = false;
      if (this.activeTimerIndex === index) {
        this.activeTimerIndex = null;
      }

      // 음악 일시 정지
      this.$refs.audioElement.pause();
      this.$refs.audioElement.currentTime = 0;
    },
    formatTime(time) {
      const minutes = Math.floor(time / 60);
      const seconds = time % 60;
      return `${this.padTime(minutes)}:${this.padTime(seconds)}`;
    },
    padTime(time) {
      return time.toString().padStart(2, "0");
    },
    openModal(modalName) {
      if (modalName === "addExercise") {
        this.showModal = true;
        this.exerciseTitle = "";
      }
    },
    addExercise() {
      // 운동 추가 로직을 구현합니다.
      // this.exerciseTitle에 입력된 운동 제목을 사용하여 추가 작업을 수행합니다.
      // 추가 작업 후 모달을 닫습니다.
      this.showModal = false;
    },
    goToGroupList() {
      // 내 그룹으로 가는 라우터 링크를 실행합니다.
      this.$router.push({ name: "List" });
    },
    getExerciseImage(index) {
      return require(`@/assets/${index + 1}.gif`);
    },
  },
};
</script>

<style scoped>
.container {
  margin-top: 50px;
}

.time-container {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #fedd59;
  padding: 5px;
  border: 1px solid #000000;
  margin-bottom: 25px;
  border-radius: 20px;
}

.today-time {
  margin: 0;
  font-size: 28px;
}

.total-time {
  margin: 10px;
  font-size: 32px;
}

.timer {
  margin-bottom: 20px;
  border-bottom: 1px solid #dbbc74;
  padding-bottom: 20px;
}

.timer-display {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.timer-text {
  margin-right: 10px;
}

.timer-value {
  margin-right: 10px;
}

.timer-button {
  margin-left: 10px;
}

.modal-button {
  margin: 5px;
  background-color: #f3df8c;
}

.exercise-image {
  width: 120px;
}
</style>
