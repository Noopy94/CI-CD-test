<template>
  <div class="container">
    <br />
    <div class="text-center">
      <h1 v-if="loginUser">{{ loginUser.nickname }}님 즐거운 운동되세요.</h1>
      <h1 v-else></h1>
    </div>
    <br />
    <div class="item-wrapper">
      <div class="container2">
        <router-link :to="{ name: 'VideoSearch' }" class="item front1">
          <img class="icon" src="@/assets/youtube.png" />
        </router-link>
        <router-link :to="{ name: 'VideoSearch' }" class="item back1">
          <img class="icon" src="@/assets/youtube.png" />
        </router-link>
      </div>

      <div class="container3">
        <router-link :to="{ name: 'Exercise' }" class="item front2">
          <img class="icon" src="@/assets/barbell.png" />
        </router-link>
        <router-link :to="{ name: 'Exercise' }" class="item back2">
          <img class="icon" src="@/assets/barbell.png" />
        </router-link>
      </div>
    </div>
    <router-view />
    <!-- <video-list></video-list> -->
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "HomeView",
  mounted() {
    this.$store
      .dispatch("keepLogin")
      .then(() => {
        if (this.$store.state.loginStore.loginYN) {
          console.log("로그인유지");
        } else {
          console.log("로그인유지실패");
        }
      })
      .catch(() => {
        console.log("로그인유지로직오류");
      });
  },
  computed: {
    ...mapState(["loginUser"]),
  },
  data() {
    return {
      message: "DoTheJi 운동 사이트",
    };
  },
};
</script>

<style>
* {
  font-family: "Hanna";
}
.text-center {
  text-align: center;
}
.icon {
  width: 86%;
}
</style>
<style scoped>
.container2 {
  display: flex;
  justify-content: space-between;
}

.container3 {
  display: flex;
  justify-content: space-between;
}

.item-wrapper {
  display: flex;
  justify-content: space-between;
  margin-left: 80px;
}

.container .item {
  font-size: 35px;
  backface-visibility: hidden;
  transition: 1s;
}

.container2 .item.front1 {
  position: absolute;
  transform: rotateY(0deg);
}

.container2:hover .item.front1 {
  transform: rotateY(180deg);
}

.container2 .item.back1 {
  transform: rotateY(-180deg);
}

.container2:hover .item.back1 {
  transform: rotateY(0deg);
}

.container3 .item.front2 {
  position: absolute;
  transform: rotateY(0deg);
}

.container3:hover .item.front2 {
  transform: rotateY(180deg);
}

.container3 .item.back2 {
  transform: rotateY(-180deg);
}

.container3:hover .item.back2 {
  transform: rotateY(0deg);
}
</style>
