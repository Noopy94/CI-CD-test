<template>
  <div id="app">
    <header-nav />

    <router-view />
  </div>
</template>
<script>
import HeaderNav from "@/components/common/HeaderNav.vue";
export default {
  name: "App",
  components: {
    HeaderNav,
  },
};
</script>
<style>
@font-face {
  font-family: "Hanna";
  src: url("assets/font/BMHANNAPro.ttf");
}
input[type="password"] {
  font-family: "굴림";
}

* {
  margin: 0;
  padding: 0;
  /* box-sizing: border-box; */
  list-style: none;
}
.text-center {
  text-align: center;
}
.btn {
  white-space: nowrap;
}
/* .container {
  margin: 0px 30px;
} */
</style>
