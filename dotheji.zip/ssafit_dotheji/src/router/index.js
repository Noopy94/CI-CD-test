import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import LoginForm from "@/components/LoginForm.vue";
import UserRegist from "@/components/user/UserRegist.vue";
import UserMypage from "@/components/user/UserMypage.vue";
import UserModify from "@/components/user/UserModify.vue";
import UserView from "../views/UserView.vue";
import GroupView from "../views/GroupView.vue";
import GroupList from "@/components/group/GroupList.vue";
import GroupRegist from "@/components/group/GroupRegist.vue";
import GroupDetail from "@/components/group/GroupDetail.vue";
import VideoView from "../views/VideoView.vue";
import VideoSearch from "@/components/video/VideoSearch.vue";
import VideoDetail from "@/components/video/VideoDetail.vue";
import CommentRegist from "@/components/comment/CommentRegist.vue";
import GroupSearch from "@/components/group/GroupSearch.vue";
import UserSearch from "@/components/group/UserSearch.vue";
import Exercise from "../views/ExerciseView.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "home",
    component: Home,
  },

  {
    path: "/login",
    name: "Login",
    component: LoginForm,
  },
  {
    path: "/signup",
    name: "Signup",
    component: UserRegist,
  },
  {
    path: "/group",
    component: GroupView,
    children: [
      {
        path: "regist",
        name: "Regist",
        component: GroupRegist,
      },
      {
        path: "",
        name: "List",
        component: GroupList,
      },
      {
        path: "/:id",
        name: "Detail",
        component: GroupDetail,
      },
      {
        path: "groupsearch",
        name: "GroupSearch",
        component: GroupSearch,
      },
      {
        path: "/:id/usersearch",
        name: "UserSearch",
        component: UserSearch,
      },
    ],
  },
  {
    path: "/user",
    component: UserView,
    children: [
      {
        path: "mypage",
        name: "Mypage",
        component: UserMypage,
      },
      {
        path: "modify",
        name: "Modify",
        component: UserModify,
      },
    ],
  },
  {
    path: "/video",
    component: VideoView,
    children: [
      {
        path: "search",
        name: "VideoSearch",
        component: VideoSearch,
      },
      {
        path: "detail/:videoId",
        name: "VideoDetail",
        component: VideoDetail,
      },
    ],
  },
  {
    path: "/comment",
    name: "CommentRegist",
    component: CommentRegist,
  },

  {
    path: "/exercise/home",
    name: "Exercise",
    component: Exercise,
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

export default router;
