import Vue from "vue";
import Vuex from "vuex";
import axios from "axios";
import router from "@/router";

Vue.use(Vuex);
// const REVIEW_REST_URL = `http://localhost:9999/api-review`;
const USER_REST_URL = `http://localhost:9999/api-user`;
// const VIDEO_REST_URL = `http://localhost:9999/api-video`;
const Group_REST_API = `http://localhost:9999/api-group`;
const COMMENT_REST_API = `http://localhost:9999/api-comment`;

export default new Vuex.Store({
  state: {
    comments: [],
    videos: [],
    video: null,
    user: {},
    loginUser: null,
    idcheck: false,
    nicknamecheck: false,
    users: [],
    searchUsers: [],
    rankCalendars: [],
    groups: [],
    searchGroups: [],
    group: {},
    calendars: [],
  },
  getters: {
    userCnt: function (state) {
      return state.users.length;
    },
    searchUserCnt: function (state) {
      return state.searchUsers.length > 0 ? state.searchUsers.length : null;
    },
    searchGroupCnt: function (state) {
      return state.searchGroups.length > 0 ? state.searchGroups.length : null;
    },
    rankCnt: function (state) {
      return state.rankCalendars.length;
    },
    SEARCH_NAME: function (state, groups) {
      state.searchGroups = groups;
    },
    UsersCnt: function (state) {
      return state.users.length > 0 ? state.users.length : null;
    },
  },
  mutations: {
    SEARCH_YOUTUBE(state, videos) {
      state.videos = videos;
    },
    CLICK_VIDEO(state, video) {
      state.video = video;
    },
    CREATE_COMMENTS(state, comments) {
      state.comments = comments;
    },

    CREATE_USER: function (state, user) {
      state.user = user;
    },
    USER_LOGIN: function (state, user) {
      state.loginUser = user;
    },
    USER_CHECK_ID: function (state, idcheck) {
      state.idcheck = idcheck;
    },
    USER_CHECK_NICKNAME: function (state, nicknamecheck) {
      state.nicknamecheck = nicknamecheck;
    },
    LOGOUT: function (state) {
      state.loginUser = null;
    },
    CREATE_GROUP: function (state, group) {
      state.group = group;
    },
    SEARCH_NAME: function (state, users) {
      state.searchUsers = users;
    },
    SEARCH_NAMEGROUP: function (state, groups) {
      state.searchGroups = groups;
    },
    SET_GROUP: function (state, group) {
      state.group = group;
    },
    SET_USERS: function (state, users) {
      state.users = users;
    },
    SET_GROUPS: function (state, groups) {
      state.groups = groups;
    },
  },
  actions: {
    registComment({ commit }, comment) {
      const API_URL = `${COMMENT_REST_API}/comment`;
      console.log(comment);
      axios({
        url: API_URL,
        method: "POST",
        data: comment,
      })
        .then(() => {
          console.log(comment);
          commit("CREATE_COMMENT", comment);
          alert("등록되었습니다.");
        })
        .catch((err) => {
          console.log(err);
        });
    },

    getComments({ commit }, video) {
      console.log(video);
      const videoid = video.id.videoId;
      console.log(videoid);
      const API_URL = `${COMMENT_REST_API}/comment/${videoid}`;
      console.log(API_URL);
      axios({
        url: API_URL,
        method: "GET",
        data: videoid,
      })
        .then((res) => {
          commit("CREATE_COMMENTS", res.data);
          console.log(res.data);
          console.log("댓글목록입니다.");
        })
        .catch((err) => {
          console.log(err);
        });
    },

    searchYoutube({ commit }, payload) {
      const URL = "https://www.googleapis.com/youtube/v3/search";
      const API_KEY = process.env.VUE_APP_YOUTUBE_API_KEY;
      axios({
        url: URL,
        method: "GET",
        params: {
          key: API_KEY,
          part: "snippet",
          q: payload + "운동" + "다이어트",
          type: "video",
          maxResults: 6,
        },
      })
        .then((res) => {
          console.log(res);
          commit("SEARCH_YOUTUBE", res.data.items);
        })
        .catch((err) => console.log(err));
    },
    //payload : 비디오 객체가 들어온다.
    clickVideo({ commit }, payload) {
      commit("CLICK_VIDEO", payload);
    },
    createUser: function ({ commit }, user) {
      console.log(user);
      const API_URL = `${USER_REST_URL}/user`;
      axios({
        url: API_URL,
        method: "POST",
        data: user,
      })
        .then(() => {
          console.log(user);
          commit("CREATE_USER", user);
          alert("등록되었습니다.");
          router.push("/");
        })
        .catch((err) => {
          console.log(err);
        });
    },

    userLogin({ commit }, user) {
      const API_URL = `${USER_REST_URL}/login`;
      console.log(user);
      axios({
        url: API_URL,
        method: "POST",
        data: user,
      })
        .then((res) => {
          console.log(res);
          // sessionStorage.setItem("access-token", res.data["access-token"]);

          commit("USER_LOGIN", res.data); //필요하다면 데이터도 같이 올려보내라
          alert("로그인되었습니다");
          router.push("/");
        })
        .catch((err) => {
          alert("아이디 및 비밀번호를 확인해주세요");
          console.log(err);
        });
    },
    checkId({ commit }, user_id) {
      const API_URL = `${USER_REST_URL}/checkid/${user_id}`;
      axios({
        url: API_URL,
        method: "GET",
        data: user_id,
      })
        .then((res) => {
          console.log(user_id);
          console.log(res);
          commit("USER_CHECK_ID", res.data);
          alert("사용가능한 id 입니다"); //필요하다면 데이터도 같이 올려보내라
        })
        .catch((err) => {
          console.log(err);
        });
    },
    checkNickname({ commit }, nickname) {
      const API_URL = `${USER_REST_URL}/checknickname/${nickname}`;
      axios({
        url: API_URL,
        method: "GET",
        data: nickname,
      })
        .then((res) => {
          console.log(nickname);
          console.log(res);
          commit("USER_CHECK_NICKNAME", res.data);
          alert("사용가능한 nickname 입니다"); //필요하다면 데이터도 같이 올려보내라
        })
        .catch((err) => {
          console.log(err);
        });
    },
    createGroup: function ({ commit }, g) {
      const API_URL = `${Group_REST_API}/group`;
      console.log(g);
      axios({
        url: API_URL,
        method: "POST",
        data: g,
      })
        .then((res) => {
          commit("CREATE_GROUP", res.data);

          alert("등록되었습니다.");
          router.push("/group");
        })
        .catch((err) => {
          console.log(err);
        });
    },

    searchName: function ({ commit }, name) {
      const API_URL = `${USER_REST_URL}/search`;
      axios({
        url: API_URL,
        method: "GET",
        params: {
          nickname: name,
        },
      })
        .then((res) => {
          commit("SEARCH_NAME", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    modifyUser: function ({ commit }, user) {
      console.log(user);
      const API_URL = `${USER_REST_URL}/user`;
      axios({
        url: API_URL,
        method: "PUT",
        data: user,
      })
        .then(() => {
          console.log(user);
          commit("MODIFY_USER", user);
          alert("정보가 수정되었습니다. 다시 로그인 해주세요");
        })
        .catch((err) => {
          console.log(err);
        });
    },
    inviteUser: function ({ commit }, i) {
      console.log(commit);
      const API_URL = `${Group_REST_API}/invite`;
      console.log(i);
      axios({
        url: API_URL,
        method: "POST",
        data: i,
      })
        .then(() => {
          alert("초대되었습니다.");
          router.push("/group");
        })
        .catch((err) => {
          console.log(err);
        });
    },
    searchGroupName: function ({ commit }, name) {
      const API_URL = `${Group_REST_API}/search`;
      axios({
        url: API_URL,
        method: "GET",
        params: {
          groupname: name,
        },
      })
        .then((res) => {
          commit("SEARCH_NAMEGROUP", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    setGroup: function ({ commit }, id) {
      const API_URL = `${Group_REST_API}/group/${id}`;
      console.log(id);
      axios({
        url: API_URL,
        method: "GET",
      })
        .then((res) => {
          console.log("여기오냐?");
          commit("SET_GROUP", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },

    setUsers: function ({ commit }, id) {
      const API_URL = `${USER_REST_URL}/users`;
      return axios({
        url: API_URL,
        method: "GET",
        params: {
          groupid: id,
        },
      })
        .then((res) => {
          console.log(res.data);
          commit("SET_USERS", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    setGroups: function ({ commit }, id) {
      const API_URL = `${Group_REST_API}/group`;
      return axios({
        url: API_URL,
        method: "GET",
        params: {
          userid: id,
        },
      })
        .then((res) => {
          console.log(res.data);
          commit("SET_GROUPS", res.data);
        })
        .catch((err) => {
          console.log(err);
        });
    },
    keepLogin({ commit }) {
      console.log("keepLogin!!!!!!");
      return axios.post("/api/keepLogin").then((response) => {
        console.log(response.data);
        if (response.data == "유지성공") {
          commit("change");
        }
      });
    },
  },
  modules: {},
});
